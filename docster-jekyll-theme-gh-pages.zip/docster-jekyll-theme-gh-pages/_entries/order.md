---
sectionid: order
sectionclass: h3
parent-id: collection-entries
is-parent: yes
number: 3120
title: Order
---
Okay, I have touched upon the order before. As I said, you have two options on how to determine the order of your entries.

The choice of how you go about it, is yours. Both ways have pros and cons, that you have to check for yourself.

We went with the front matter version here, but might go with the numbered files on another Docs. So it might just depend on your mood as well.