---
sectionid: intro
sectionclass: h1
title: Introduction
number: 1000
---
Welcome to this demo (and documentation) of Docster. A Documentation Theme for jekyll. 

Here we'll show you what the theme looks like and how you will use it. Docster makes setting up an organized Documentation a breeze.
It has a sidebar, that is a table of contents and consists of links, that will scroll you to the respective section.

Docster is perfect for really long and complex as well as short and simple Docs.