---
sectionclass: h2
sectionid: collection-entries
parent-id: content
is-parent: yes
number: 3100
title: Collection Entries
---
Okay, so the collection is the entries collection. All of your documentation sections will be placed within that folder.
The index file will then go over every one of these and put them together.

There are different ways on how you can take care of the order of the entries, depending on which one you chose, you will either have to work with filenames, or with the `number` front matter. 

If you decide to work with file-names, you will just prefix your file names with numbers.
