---
sectionid: sass
sectionclass: h2
parent-id: set-up
title: Sass
number: 2200
---
The styles applied to Docster are very minimal. There are two colors used throughout the site and some syntax highlighting stylesheet.

If you want to change the colors you will find them within the `_sass` directory in the `modules/_color` file. If you want to go with something else than green, you might want to change the variable name (and then just do a folder-wide search with the editor to replace. Almost every editor should have this feature).

Other than that feel free to just browse through the code and change things up as you like.