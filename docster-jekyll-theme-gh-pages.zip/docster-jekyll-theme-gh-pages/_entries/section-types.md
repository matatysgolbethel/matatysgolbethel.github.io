---
sectionid: section-types
sectionclass: h3
parent-id: collection-entries
is-parent: yes
number: 3110
title: Section Types
---
There are three different levels supported, basically four, but the `h4` tags will not be included, within the navigation by default. Read on if you want to change that.
