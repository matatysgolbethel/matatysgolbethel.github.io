---
sectionclass: h1
sectionid: content
is-parent: yes
title: Content
number: 3000
---
Now for what Docster is all about. The content.

You want to know how all of this works, right?

So Docster makes use of the collections feature, every entry will be written separately and then be compiled into one single HTML file. This ensures that the output is minimal. So in case that you don't want to publish the documentation online, it has the perfect format to be put within another folder. Like for example the Download Package of a Theme.